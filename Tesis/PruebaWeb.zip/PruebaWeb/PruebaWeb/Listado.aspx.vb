﻿Imports System.ServiceModel

Public Class Listado
    Inherits System.Web.UI.Page
    Private Conexion As New SrComunicacion.ComunicacionClient

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        GvListaProgramas.DataSource = CallListaProgramas()
        GvListaProgramas.DataBind()
    End Sub

    Private Function CallListaProgramas() As IEnumerable(Of SrComunicacion.ConfCarrera)
        Dim Lista As IEnumerable(Of SrComunicacion.ConfCarrera) = Nothing
        Try
            Lista = Conexion.TraeCarreras()
        Catch ex As FaultException(Of SrComunicacion.AppError)
            ' Throw New Exception(ex.Detail.Detalle)
            Response.Write(ex.Detail.Detalle)
        End Try

        Return Lista
    End Function


End Class