﻿Public Class AppError
    Private _descripcion As String
    Property Detalle As String
        Get
            Return _descripcion
        End Get
        Set(value As String)
            Dim file As System.IO.StreamWriter
            file = My.Computer.FileSystem.OpenTextFileWriter("c:\LogApp\" & Date.Now.ToShortDateString & ".txt", True)
            file.WriteLine(value)
            file.Close()
        End Set
    End Property

End Class
