﻿Public Class Programas
    Property Codigo As Integer
    Property Nombre As String
    Property Fecha As Date
    Property Valido As Boolean
End Class
