﻿Public Class ConfCarrera
    Property CarCodigo As Integer
    Property CarNombre As String

    Property AñoCreacion As Integer
    Property AñoTermino As Integer

    Property EscCodigo As Integer
    Property EscNombre As String

    Property CodMinisterio As Integer
    Property CodDEMRE As Integer

    Property TipCarrera As Parametro
    Property TipPlan As Parametro
    Property TipArea As Parametro

    Property Email As String
End Class
