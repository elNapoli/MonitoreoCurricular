﻿Public Class Parametro

    Property Valor As Integer
    Property Descripcion As String
End Class
