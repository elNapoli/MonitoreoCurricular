﻿' NOTA: puede usar el comando "Cambiar nombre" del menú contextual para cambiar el nombre de interfaz "IService1" en el código y en el archivo de configuración a la vez.
Imports Estructura
<ServiceContract()>
Public Interface IComunicacion

    <OperationContract(), FaultContract(GetType(AppError))>
    Function TraeCarreras() As IEnumerable(Of ConfCarrera)

End Interface
 
