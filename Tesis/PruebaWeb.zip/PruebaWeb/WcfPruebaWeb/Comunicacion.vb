﻿Imports Estructura
Imports Conexion.ConexionFactory
Imports System.Configuration

' NOTA: puede usar el comando "Cambiar nombre" del menú contextual para cambiar el nombre de clase "Service1" en el código y en el archivo de configuración a la vez.
Public Class Comunicacion
    Implements IComunicacion

    Private Shared cnn As IConector 'abstract factory   

    Sub New()
        cnn = New Conexion.ConexionFactory.Sybase.Conector(ConfigurationManager.AppSettings.Get("CURRICULAR"))

        Dim ci As System.Globalization.CultureInfo = New Globalization.CultureInfo("es-CL")
        ci.NumberFormat.NumberDecimalDigits = 2
        ci.NumberFormat.NumberDecimalSeparator = ","


        Threading.Thread.CurrentThread.CurrentCulture = ci
        Threading.Thread.CurrentThread.CurrentUICulture = ci
    End Sub

    Private Shared Function Tipos(Parametro As String) As IEnumerable(Of Estructura.Parametro)
        Dim ret As New List(Of Estructura.Parametro)

        Dim Parametros As New List(Of Parameter)
        Parametros.Add(New Parameter With {.Nombre = "@ParTab", .Valor = Parametro, .Tipo = Parameter.TypeDB.DbChar, .Tamagno = 15})
       
        Dim dr As IEnumerable(Of DataRow)
        Try
            dr = cnn.Ejecuta("GlbSrvComboParamCarga", Parametros)
        Catch ex As Exception
            Throw New FaultException(Of AppError)(New AppError With {.Detalle = ex.Message.ToString})
        End Try

        If (From x In dr Select x).Count = 0 Then
            Throw New FaultException(Of AppError)(New AppError With {.Detalle = "No existen parametros"})
        End If

        For Each item In dr
            ret.Add(New Estructura.Parametro With {
                    .Valor = Integer.Parse(item("ParTabCod").ToString),
                    .Descripcion = item("ParTabCodDes").ToString})
        Next

        Return ret
    End Function

    Public Function TraeCarreras() As IEnumerable(Of ConfCarrera) Implements IComunicacion.TraeCarreras
        Dim dr As IEnumerable(Of DataRow) = Nothing
        Try
            dr = cnn.Ejecuta("MatSrvCargaCarrerasParaExp")
        Catch ex As Exception
            Throw New FaultException(Of AppError)(New AppError With {.Detalle = ex.Message.ToString})
        End Try

        If dr Is Nothing Then Throw New Exception("La función no retorna valor")
        Dim ret As New List(Of ConfCarrera)
        'Tipos
        For Each item As DataRow In dr
            Dim TipCarrera As Parametro = Tipos("ParTipCarrera").Where(Function(x) x.Valor = item(6)).FirstOrDefault
            Dim TipPlan As Parametro = Tipos("ParTipPlan").Where(Function(x) x.Valor = item(7)).FirstOrDefault
            Dim TipArea As Parametro = Tipos("ParCodArea").Where(Function(x) x.Valor = item(11)).FirstOrDefault

            ret.Add(New ConfCarrera With {
                    .CarCodigo = item(0),
                    .CarNombre = item(1),
                    .EscCodigo = item(4),
                    .EscNombre = item(5),
                    .AñoCreacion = item(2),
                    .AñoTermino = item(3),
                    .Email = item(13),
                    .CodMinisterio = item(8),
                    .CodDEMRE = item(9),
                    .TipCarrera = TipCarrera,
                    .TipPlan = TipPlan,
                    .TipArea = TipArea
                }
            )
        Next
        Return ret.AsEnumerable
    End Function
End Class
